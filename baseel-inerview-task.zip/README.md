Clone the Source code from https://github.com/Sudhakar1470820/Baseel-Interview-Task.git

## Getting Started

First, install the necessary dependencies using below Command:
npm install

run the development server:

```bash
npm run dev
# or
yarn dev
# or
pnpm dev
# or
bun dev
```

Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.